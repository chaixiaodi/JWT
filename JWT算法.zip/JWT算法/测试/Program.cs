﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 测试
{
    class Program
    {
        static void Main(string[] args)
        {
            dynamic value;
            for (Int32 demo = 0; demo < 2; demo++)
            {
                value = (demo == 0) ? (dynamic)5:(dynamic) "A";
                value = value + value;
                M(value);
                Console.ReadKey();
            }
        }
        public static void M(int v)
        {
            Console.WriteLine("MInt32="+v);
        }

        public static void M(string s)
        {
            Console.WriteLine("M(String)="+s);
        }
    }
}
